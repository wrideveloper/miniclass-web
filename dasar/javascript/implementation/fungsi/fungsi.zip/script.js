function berubah(warna) {
    document.getElementById("kotak").style.background=warna;
  }